#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

static long n_p = 1000000; 
 
int main( int argc, char **argv ) {
   int mi_id, procs;
   //struct MPI_Status stat;

   int i;
   double paso;
   double x, pi, suma=0.0;
   double sumf = 0.0;

   paso = 1.0 / (double) n_p;

   // Inicializacion de la parte paralela.
   MPI_Init( &argc, &argv );
   MPI_Comm_size( MPI_COMM_WORLD, &procs);
   MPI_Comm_rank( MPI_COMM_WORLD, &mi_id);
              
   for(i=0+mi_id; i < n_p; i=i+procs){
       x = (i + 0.5) * paso;
       suma = suma + 4.0 / (1.0 + x * x);
   }
   if(mi_id == 0){
      sumf=suma;
      for(i=1; i<procs; i++){
         MPI_Recv(&suma,1, MPI_DOUBLE, MPI_ANY_SOURCE,2, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
         sumf=sumf+suma;
      }
   }else{
      MPI_Send(&suma, 1, MPI_DOUBLE,0,2, MPI_COMM_WORLD); 
   }
    
    if(mi_id == 0){
       pi = paso * sumf;
       printf("El valor aproximado de pi es: %3.10lf \n", pi);
    }
    MPI_Finalize();
    return EXIT_SUCCESS;
 }
