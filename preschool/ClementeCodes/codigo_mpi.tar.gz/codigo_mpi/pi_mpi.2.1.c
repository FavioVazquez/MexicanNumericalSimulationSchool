#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

static long n_p = 1000000; 
 
int main( int argc, char **argv ) {
   int mi_id, procs;

   int i;
   double paso;
   double x, pi, suma=0.0;
   double *sumf; // = 0.0;

   paso = 1.0 / (double) n_p;

   // Inicializacion de la parte paralela.
   MPI_Init( &argc, &argv );
   MPI_Comm_size( MPI_COMM_WORLD, &procs);
   MPI_Comm_rank( MPI_COMM_WORLD, &mi_id);
              
   for(i=0+mi_id; i < n_p; i=i+procs){
       x = (i + 0.5) * paso;
       suma = suma + 4.0 / (1.0 + x * x);
   }
   if(mi_id == 0){
      sumf = (double*) malloc(sizeof(double)*procs);
   }
   
    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Gather(&suma,1,MPI_DOUBLE, sumf,1, MPI_DOUBLE,0,MPI_COMM_WORLD);
  
    if(mi_id == 0){
       double sum_t=0.0;
       for(i=0;i<procs;i++)
          sum_t = sum_t + sumf[i];
       pi = paso * sum_t;
       printf("El valor aproximado de pi es: %3.10lf \n", pi);
       free(sumf);
    }
    MPI_Barrier(MPI_COMM_WORLD);
    MPI_Finalize();
    return EXIT_SUCCESS;
 }
