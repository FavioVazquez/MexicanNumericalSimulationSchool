#include <stdio.h>
#include <stdlib.h>

#include <mpi.h>
 
int main( int argc, char* argv[] ) {
  int mi_id, procs;

   double comparte;
  
  // Inicializacion de la parte paralela.
  MPI_Init( &argc, &argv );
  MPI_Comm_size( MPI_COMM_WORLD, &procs);
  MPI_Comm_rank( MPI_COMM_WORLD, &mi_id);

  comparte=(double)mi_id * 14.52;
 
  printf("Proceso n. %d de un total de %d procesos. Valor = %lf\n", 
	 mi_id, procs,comparte);

  if(mi_id == 0){
     comparte = 3541324.7230;
     printf("\n\n");
  }
  MPI_Barrier(MPI_COMM_WORLD);
//MPI_Bcast(void *buffer, int cantidad, MPI_Datatype tipo,
//int raíz, MPI_Comm comunicador)
//
  MPI_Bcast(&comparte,1,MPI_DOUBLE,0,MPI_COMM_WORLD);

  printf("Proceso n. %d de un total de %d procesos. Valor = %lf\n", 
	 mi_id, procs,comparte);

  MPI_Finalize();
  
  return EXIT_SUCCESS;
}
