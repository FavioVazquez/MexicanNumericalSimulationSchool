/* do not edit - created by the src/scripts/version script */
#if defined(GETPARAM_VERSION_ID)
static char *version_h = "$Id: version.h,v 1.30 2006/08/06 01:36:09 pteuben Exp $";
#endif
#define NEMO_VERSION "3.2.5"
