/*
 * outdefv.c: dummy definition of the required "extern string outdefv[]"
 *         This is to ensure that programmers who forgot to declare it,
 *         deliberate or not, will have a linkable program.
 *
 */

#include "../../../include/stdinc.h"

string outdefv[] = {
    NULL,
};
