/*==============================================================================
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 HEADER: cmdline_defs.h		[TEMPLATE04]
 Written by: M.A. Rodriguez-Meza
 Starting date: May 2006
 Purpose: Definitions for importing arguments from the command line
 Language: C
 Use: '#include "cmdline_defs.h"
 Use in routines and functions: (main)
 External headers: stdinc.h
 Comments and notes:
 Info: M.A. Rodriguez-Meza
 Depto. de Fisica, ININ
 Apdo. Postal 18-1027 Mexico D.F. 11801 Mexico
 e-mail: marioalberto.rodriguez@inin.gob.mx
 http://www.astro.inin.mx/mar
 
 Major revisions:
 Copyright: (c) 2005-2012 Mar.  All Rights Reserved
 ================================================================================
 Legal matters:
 The author does not warrant that the program and routines it contains 
 listed below are free from error or suitable for particular applications, 
 and he disclaims all liability from any consequences arising from their use.
 ==============================================================================*/

#ifndef _cmdline_defs_h
#define _cmdline_defs_h

#define HEAD1	"NagBody"
#define HEAD2	"Template Code for the solution of N dif. eqs."
#define HEAD3	"Several methods to use"

string defv[] = {  ";"HEAD1": " HEAD2 "\n\t " HEAD3,
    "x=1.0",                ";x value",
    "dx=1/5",               ";dx integration step",
    "xstop=2.0",			";x value to stop integration",
    "maxnsteps=100",        ";Maximum number of steps", ":maxn",
    "integration_method=rk4",	";Integration method to use", ":im",
    "out=sols.dat",          ";Output file of the solutions", ":o",
    "outfmt=col-ascii",     ";Output file format of the solutions", ":ofmt",
    "dxout=2/5",			";Data output x step", ":dxo",
    "dxoutinfo=2/5",		";Info output x step", ":dxoinfo",
    "options=",				";Various control options", ":opt",
    "paramfile=",			";Parameter input file. Overwrite what follows",
    "Version=0.2",			";Mar 2005-2012",
    NULL,
};

#endif // ! _cmdline_defs_h
