/*==============================================================================
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 MODULE: template.c				[TEMPLATE04]
 Written by: M.A. Rodriguez-Meza
 Starting date:	May 2006
 Purpose:
 Language: C
 Use:
 Routines and functions:
 External modules, routines and headers:
 Comments and notes:
 Info: M.A. Rodriguez-Meza
 Depto. de Fisica, ININ
 Apdo. Postal 18-1027 Mexico D.F. 11801 Mexico
 e-mail: marioalberto.rodriguez@inin.gob.mx
 http://www.astro.inin.mx/mar
 
 Major revisions:
 Copyright: (c) 2005-2012 Mar.  All Rights Reserved
 ================================================================================
 Legal matters:
 The author does not warrant that the program and routines it contains
 listed below are free from error or suitable for particular applications,
 and he disclaims all liability from any consequences arising from their	use.
 ==============================================================================*/

#include "../../../General_libs/general/stdinc.h"
#include "../../../General_libs/math/numrec.h"
#include "../../../General_libs/math/mathfns.h"
#include "globaldefs.h"
#include "protodefs.h"


local void integration(double y[], double dydx[], int n, double x, double h, double yout[],
               void (*derivs)(double, double [], double []));
local void rk4(double y[], double dydx[], int n, double x, double h, double yout[],
               void (*derivs)(double, double [], double []));

local void stepsystem(void);

local real *y;
local real *dydx;

void MainLoop(void)
{
    int i;

	y=dvector(1,NEQS);
	dydx=dvector(1,NEQS);
	yout=dvector(1,NEQS);
	y[1]=bessj0(gd.xnow);
	y[2]=bessj1(gd.xnow);
	y[3]=bessj(2,gd.xnow);
	y[4]=bessj(3,gd.xnow);
	derivs(gd.xnow,y,dydx);

    if (gd.nstep == 0) {
        for (i=1;i<=NEQS;i++) yout[i] = y[i];
        output();
    }

    if (gd.dx != 0.0)
        while (cmd.xstop - gd.xnow > 0.01*gd.dx) {
            stepsystem();
            output();
			CheckStop();
			if (gd.stopflag) break;
        }

	free_dvector(yout,1,NEQS);
	free_dvector(dydx,1,NEQS);
	free_dvector(y,1,NEQS);
}


local void stepsystem(void)
{
	int i;

//    y, dydx are evaluated at xnow ... yout is the solutions at xnow+dx
    integration(y,dydx,NEQS,gd.xnow,gd.dx,yout,derivs); 

    for (i=1;i<=NEQS;i++) y[i] = yout[i];
    gd.nstep++;
    gd.xnow = gd.xnow + gd.dx;
	derivs(gd.xnow,y,dydx);
}

void derivs(double x,double y[],double dydx[])
{
	dydx[1] = -y[2];
	dydx[2]=y[1]-(1.0/x)*y[2];
	dydx[3]=y[2]-(2.0/x)*y[3];
	dydx[4]=y[3]-(3.0/x)*y[4];
}

#define RK4         0
#define NULLMETHOD  1

local void integration(double y[], double dydx[], int n, double x, double h, 
                       double yout[],void (*derivs)(double, double [], double []))
{
    switch (gd.method_int) {
        case RK4:
            rk4(y,dydx,n,x,h,yout,derivs);
            break;
            
        case NULLMETHOD:
            rk4(y,dydx,n,x,h,yout,derivs);
            break;

        default:
            rk4(y,dydx,n,x,h,yout,derivs);
            break;
    }
}


local void rk4(double y[], double dydx[], int n, double x, double h, double yout[],
         void (*derivs)(double, double [], double []))
{
	int i;
	double xh,hh,h6,*dym,*dyt,*yt;
    
	dym=dvector(1,n);
	dyt=dvector(1,n);
	yt=dvector(1,n);
	hh=h*0.5;
	h6=h/6.0;
	xh=x+hh;
	for (i=1;i<=n;i++) yt[i]=y[i]+hh*dydx[i];
	(*derivs)(xh,yt,dyt);
	for (i=1;i<=n;i++) yt[i]=y[i]+hh*dyt[i];
	(*derivs)(xh,yt,dym);
	for (i=1;i<=n;i++) {
		yt[i]=y[i]+h*dym[i];
		dym[i] += dyt[i];
	}
	(*derivs)(x+h,yt,dyt);
	for (i=1;i<=n;i++)
		yout[i]=y[i]+h6*(dydx[i]+dyt[i]+2.0*dym[i]);
	free_dvector(yt,1,n);
	free_dvector(dyt,1,n);
	free_dvector(dym,1,n);
}


void integration_method_string_to_int(string method_str,int *method_int)
{
    *method_int=-1;
    if (strcmp(method_str,"rk4") == 0) {
        *method_int = RK4;
        strcpy(gd.integration_method_comment, "rk4 integration method");
    } else
    if (strnull(method_str)) {              
        *method_int = NULLMETHOD;
        strcpy(gd.integration_method_comment, 
               "null integration method ... running deafult (rk4)");
        fprintf(stdout,"\n\tintegration: default integration method (rk4)...\n");
    } else {

    fprintf(stdout,"\n\tintegration: Unknown method... %s ",cmd.integration_method);
    fprintf(stdout,
            "\n\trunning default integration method (rk4)...\n"); 
    }
}

#undef RK4
#undef NULLMETHOD

