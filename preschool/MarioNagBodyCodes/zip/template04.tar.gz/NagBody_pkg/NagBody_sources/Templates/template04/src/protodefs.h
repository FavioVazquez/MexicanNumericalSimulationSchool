/*==============================================================================
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 HEADER: protodefs.h				[TEMPLATE04]
 Written by: M.A. Rodriguez-Meza
 Starting date: May 2006
 Purpose: Definitions of global prototypes
 Language: C
 Use: '#include "protodefs.h"
 Use in routines and functions:
 External headers: None
 Comments and notes:
 Info: M.A. Rodriguez-Meza
 Depto. de Fisica, ININ
 Apdo. Postal 18-1027 Mexico D.F. 11801 Mexico
 e-mail: marioalberto.rodriguez@inin.gob.mx
 http://www.astro.inin.mx/mar
 
 Major revisions:
 Copyright: (c) 2005-2012 Mar.  All Rights Reserved
 ================================================================================
 Legal matters:
 The author does not warrant that the program and routines it contains
 listed below are free from error or suitable for particular applications,
 and he disclaims all liability from any consequences arising from their	use.
 ==============================================================================*/

#ifndef _protodefs_h
#define _protodefs_h

void derivs(double x,double y[],double dydx[]);

void integration_method_string_to_int(string,int *);

void output(void);

void MainLoop(void);
void StartRun(string, string, string, string);
void StartOutput(void);
void CheckStop(void);
void EndRun(void);

#endif // ! _protodefs_h
