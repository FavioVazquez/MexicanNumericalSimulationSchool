't" t
.TH template04 1 "January 2012" UNIX "NagBody PROJECT"
.na
.nh   

.SH NAME
template04 - TEMPLATE for developing ODE solvers codes
.SH SYNOPSIS
\fBtemplate04\fR [ \fIparameter_file_name\fR ] [ \fIoptions\fR ] 
.sp

.SH DESCRIPTION
\fBtemplate04\fR - Template to integrate ordinary differential equation using several methods.

.SH OPTIONS
All the options have the structure
.sp
\fIoption_name\fR=<option_value>
.sp
except option \fB-help\fR.
.sp

Options and their possible values are:

.IP "\fB-help\fR" 12
By writting

.sp
template04 -help
.sp

you will get the list of all parameters and their default values. An option may have an alias which is a short name of the option. If an option has an alias in the list above it comes after its description surrounded by brackets tagged with 'a:'. For example,

.sp
option_name=<option_value>	... Description ... [a: opt]
.sp
here 'opt' is the short name of the option. In the description of the options below, when an option has an alias it will be noted in the same way but before its description.

.IP "\fBparamfile\fR" 12
is the name file with the values of the input parameters. Overwrite parameters
values below. You may input this filename by only writing:
.sp
template04 paramfile=parameters_input_file_name
.sp
Parameter input file may be created by hand with the editor of your choice. Comment lines start with an "%". Follow each name option with a blank space and the option value. The order of the option lines does not matter.  Also you may create an example input file by executing
.sp
template04
.sp
This will run the \fBtemplate04\fR code with default values generating a test data internally, and when it finish you will have in your running directory the file "parameters_null-template04-usedvalues". Now you may edit this file to adapt to your own plotting parameters. This file can be overwritten so it may be helpful to change this file name to whatever apropriate.

.IP "\fBx\fR" 12
is the value of x, the initial condition for the integration.

.IP "\fBdx\fR" 12
[a: dx] is the integration step. Can be given as a ration of two numbers. Can not be zero.

.IP "\fBxstop\fR" 12
is the x value to stop the integration.

.IP "\fBmaxnsteps\fR" 12
[a: maxn]is the maximum number of steps.

.IP "\fBintegration_method\fR" 12
[a: im] is the integration method to use. Possible values are: rk4. Default value is rk4.

.IP "\fBout\fR" 12
[a: o] You give here the name of the file where it will be written the solutions.

.IP "\fBoutfmt\fR" 12
[a: ofmt] You give here the format of the file where it will be written the solutions. It could be in columns "col-ascii" in ascii format (the default). Just one method by now.

.IP "\fBdxout\fR" 12
[a: dxo] You give here the x step to generate output of solutions.

.IP "\fBdxoutinfo\fR" 12
[a: dxoinfo] You give here the x step to generate output of solutions to the standard output.

.IP "\fBoptions\fR" 12
[a: opt] you may give here various code behavior options.

.SH EXAMPLES
template04 x=1.5 dx=1/8

.sp
You will have solutions written in a file named with option \fBout\fR. You may plot the solutions using \fBnplot2d\fR code.

.SH SEE ALSO
template03(1), nplot2d(1)

.SH COPYRIGHT
Copyright (C) 1999-2012
.br
M.A. Rodriguez-Meza
.br
