/*==============================================================================
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 MODULE: template_io.c		[TEMPLATE04]
 Written by: M.A. Rodriguez-Meza
 Starting date:	May 2006
 Purpose: Routines to drive input and output data
 Language: C
 Use:
 Routines and functions:
 External modules, routines and headers:
 Comments and notes:
 Info: M.A. Rodriguez-Meza
 Depto. de Fisica, ININ
 Apdo. Postal 18-1027 Mexico D.F. 11801 Mexico
 e-mail: marioalberto.rodriguez@inin.gob.mx
 http://www.astro.inin.mx/mar
 
 Major revisions:
 Copyright: (c) 2005-2012 Mar.  All Rights Reserved
 ================================================================================
 Legal matters:
 The author does not warrant that the program and routines it contains
 listed below are free from error or suitable for particular applications,
 and he disclaims all liability from any consequences arising from their	use.
 ==============================================================================*/


#include "../../../General_libs/general/stdinc.h"
#include "../../../General_libs/math/mathfns.h"
#include "globaldefs.h"
#include "protodefs.h"

#include <sys/types.h>
#include <sys/stat.h>

// #include <strings.h>							// For unix
#include "../../../General_libs/general/strings.h"	// For Visual c

local void outputdata(void);

local void outfilefmt_string_to_int(string,int *);
local int outfilefmt_int;


#define COL_FMT         0
#define NULL_FMT        1


void StartOutput(void)
{

    if(!(gd.outstr_sols=fopen(cmd.outfile,gd.mode)))
    {
        error("can't open file `%s`\n",cmd.outfile);
    }
    fprintf(gd.outstr_sols,"%1s%4s%8s%8s%8s%8s%8s%8s%8s%8s%8s",
			"#","nstep","x","j0num","j0","j1num","j1","j2num","j2","j3num","j3");
    fprintf(gd.outstr_sols,"\n");
    fprintf(gd.outstr_sols,
			"%1s%4s%10s%8s%8s%8s%8s%8s%8s%8s%8s",
			"#","<1>","<2>","<3>","<4>","<5>","<6>","<7>","<8>","<9>","<10>");
    fprintf(gd.outstr_sols,"\n");

    fprintf(stdout,"  \t -- %s --\n", gd.integration_method_comment);

    outfilefmt_string_to_int(cmd.outfilefmt, &outfilefmt_int);

    fprintf(stdout,"\n%8s%8s%8s", "nstep", "x", "dx");
    fprintf(stdout,"%7s%10s%8s\n", "dxout","dxoutinfo","xstop");
    fprintf(stdout,"%8d%8.2f%8.4f%8.4f%8.4f%8.4f",
            gd.nstep,cmd.x,gd.dx,gd.dxout,gd.dxoutinfo,cmd.xstop);
    if (! strnull(cmd.options))
        fprintf(stdout,"\n\toptions: %s\n", cmd.options);

	fprintf(stdout,"\n\n%16s %5s %12s %12s %12s\n",
            "Bessel function:","j0","j1","j2","j3");
    
}

local void outfilefmt_string_to_int(string outfmt_str,int *outfmt_int)
{
    *outfmt_int=-1;
    if (strcmp(outfmt_str,"col-ascii") == 0) *outfmt_int = COL_FMT;
    if (strnull(outfmt_str)) *outfmt_int = 1;
}


void output(void)
{
    real xeff;
    int j;

	xeff = gd.xnow + gd.dx/8.0;

    if (xeff >= gd.xoutinfo) {
		fprintf(stdout,"\nnstep = %d  dx = %8.6f  x = %12.6f\n",
                gd.nstep,gd.dx,gd.xnow);
		fprintf(stdout,"%12s","rk4:");
		for (j=1;j<=NEQS;j++) printf(" %12.6f",yout[j]);
		fprintf(stdout,"\n%12s %12.6f %12.6f %12.6f %12.6f\n","actual:",
               bessj0(gd.xnow),bessj1(gd.xnow),bessj(2,gd.xnow),bessj(3,gd.xnow));
		gd.xoutinfo += gd.dxoutinfo;
	}

    if (! strnull(cmd.outfile) && xeff >= gd.xout) { 
        switch(outfilefmt_int) {
            case COL_FMT: 
                fprintf(gd.outlog,"\n\tcol-ascii format output\n"); 
                outputdata(); 
                break;
            case NULL_FMT: 
                fprintf(gd.outlog,"\n\tcol-ascii format output\n"); 
                outputdata(); 
                break;
            default: 
                fprintf(gd.outlog,"\n\toutput: Unknown output format...");
                fprintf(gd.outlog,"\n\tstandard format output...\n"); 
                outputdata();
                break;
        }
        gd.xout += gd.dxout;
    }
}


#undef COL_FMT
#undef NULL_FMT


#define SOLFMT \
"%5d %8.4f %7.4f %7.4f %7.4f %7.4f \
%7.4f %7.4f %7.4f %7.4f"

local void outputdata(void)
{
	fprintf(gd.outstr_sols, SOLFMT,
            gd.nstep, gd.xnow, 
            yout[1],bessj0(gd.xnow),
            yout[2],bessj1(gd.xnow),
            yout[3],bessj(2,gd.xnow),
            yout[4],bessj(3,gd.xnow));
	fprintf(gd.outstr_sols,"\n");
}

#undef SOLFMT

void CheckStop(void)
{
    char   buf[200];
	FILE *fd;
	double cpudt;

    if (gd.nstep > cmd.maxnsteps) {
		gd.stopflag = 1;
        fprintf(stdout,"\n\nMaximum number of steps reached...");
        fprintf(stdout,"\nStopping...\n\n");
    }
}

void EndRun(void)
{
    char   buf[200];
	FILE *fd;

	fclose(gd.outlog);
	fclose(gd.outstr_sols);
	printf("\nFinal CPU time : %lf\n\n", cputime() - gd.cpuinit);
}



