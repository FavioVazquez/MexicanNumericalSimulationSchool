#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>

#include "allvars.h"
#include "proto.h"


void compute_accelerations(int mode)
{
  double tstart, tend;
  
  printf("Start force computation...\n");


  tstart=second();

  gravity_tree();       // computes gravity accel. & potential

  tend=second();
  All.CPU_Gravity+= timediff(tstart,tend);


  if(N_gas>0) 
    {
      tstart=second();

      density();        // computes density, and pressure
      
      hydro_force();    // adds hydrodynamical accelerations
                        // and computes du/dt
      tend=second();
      All.CPU_Hydro+= timediff(tstart,tend);
    }

  printf("done force.\n"); fflush(stdout);
}


