
#define MPI							// Definici'on necesaria en clib.c
#undef MPI

#define DEBUG                       // Definici'on necesaria en endrun_mpi.c
#undef DEBUG


