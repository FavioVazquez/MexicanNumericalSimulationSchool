#ifndef __dj_include_strings_h_
#define __dj_include_strings_h_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef __dj_ENFORCE_ANSI_FREESTANDING

#ifndef __STRICT_ANSI__

#ifndef _POSIX_SOURCE

#include <string.h>

#endif 
#endif 
#endif 

#ifndef __dj_ENFORCE_FUNCTION_CALLS
#endif 

#ifdef __cplusplus
}
#endif

#endif 
