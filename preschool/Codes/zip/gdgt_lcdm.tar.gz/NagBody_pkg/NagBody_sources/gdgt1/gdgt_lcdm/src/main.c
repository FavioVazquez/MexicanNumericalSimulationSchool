#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "allvars.h"
#include "proto.h"


 
// Main :: the driver
int main(int argc, char **argv)
{
  double t0, t1;

  if(argc<2)
    {
      fprintf(stdout,"Parameters are missing.\n");
      fprintf(stdout,"Call with <ParameterFile> [<RestartFlag>]\n");
      exit(1);
    }

  strcpy(ParameterFile,argv[1]);

  if(argc>=3)
    RestartFlag= atoi(argv[2]);
  else
    RestartFlag=0;


  All.CPU_TreeConstruction=All.CPU_TreeWalk=All.CPU_Gravity=All.CPU_Potential=
    All.CPU_Snapshot=All.CPU_Total=All.CPU_Hydro=
      All.CPU_Predict= All.CPU_TimeLine= 0;
  
  CPUThisRun=0;

  t0=second();
  
  begrun();     // set-up run
  
  t1=second();
  CPUThisRun+= timediff(t0,t1);
  All.CPU_Total+= timediff(t0,t1);


  run();       // main simulation loop

  return 0;
}




