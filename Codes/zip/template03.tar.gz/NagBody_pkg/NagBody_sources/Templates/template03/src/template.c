/*==============================================================================
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 MODULE: template.c				[TEMPLATE03]
 Written by: M.A. Rodriguez-Meza
 Starting date:	May 2006
 Purpose:
 Language: C
 Use:
 Routines and functions:
 External modules, routines and headers:
 Comments and notes:
 Info: M.A. Rodriguez-Meza
 Depto. de Fisica, ININ
 Apdo. Postal 18-1027 Mexico D.F. 11801 Mexico
 e-mail: marioalberto.rodriguez@inin.gob.mx
 http://www.astro.inin.mx/mar
 
 Major revisions:
 Copyright: (c) 2005-2012 Mar.  All Rights Reserved
 ================================================================================
 Legal matters:
 The author does not warrant that the program and routines it contains
 listed below are free from error or suitable for particular applications,
 and he disclaims all liability from any consequences arising from their	use.
 ==============================================================================*/

#include "../../../General_libs/general/stdinc.h"
#include "../../../General_libs/math/vectmath.h"
#include "globaldefs.h"
#include "protodefs.h"

local void ForceCalculation(void);
local void StepSystem(void);

void MainLoop(void)
{

    if (gd.nstep == 0) {
        ForceCalculation();
        output();
    }
    if (gd.dtime != 0.0)
        while (cmd.tstop - gd.tnow > 0.01*gd.dtime) {
            StepSystem();
            output();
			checkstop();
			if (gd.stopflag) break;
        }
}

local void ForceCalculation(void)
{
    direct_gravcalc(bodytab, cmd.nbody);
}

local void StepSystem(void)
{
    bodyptr p;

	DO_BODY(p, bodytab, bodytab+cmd.nbody) {
        ADDMULVS(Vel(p), Acc(p), 0.5 * gd.dtime);
        ADDMULVS(Pos(p), Vel(p), gd.dtime);
    }

    ForceCalculation();

	DO_BODY(p, bodytab, bodytab+cmd.nbody) {
        ADDMULVS(Vel(p), Acc(p), 0.5 * gd.dtime);
    }

    gd.nstep++;
    gd.tnow = gd.tnow + gd.dtime;
}

