/*==============================================================================
 12345678901234567890123456789012345678901234567890123456789012345678901234567890
 NAME: main.c				[TEMPLATE03]
 Written by: M.A. Rodriguez-Meza
 Starting date: May 2006
 Purpose: Main routine
 Language: C
 Comments and notes:
 Info: M.A. Rodriguez-Meza
 Depto. de Fisica, ININ
 Apdo. Postal 18-1027 Mexico D.F. 11801 Mexico
 e-mail: marioalberto.rodriguez@inin.gob.mx
 http://www.astro.inin.mx/mar
 
 Major revision:	January 2007;
 Copyright: (c) 2005-2012 Mar.  All Rights Reserved
 ================================================================================
 
 Use: template02 -help
 Input: 	Command line parameters, Parameters file and/or icfile
 Output: ...
 Units:
 History:
 Comments and notes:
 References:
 ================================================================================
 Legal matters:
 The author does not warrant that the program and routines it contains
 listed below are free from error or suitable for particular applications,
 and he disclaims all liability from any consequences arising from their use.
 ==============================================================================*/


// TEMPLATE FILES FOR DEVELOPING CODES

// DATA STRUCTURES:

// node, *nodeptr
// body, *bodyptr : bodytab
// cell, *cellptr

// io_header_blj, *io_header_blj_ptr : hdr
// cmdline_data, *cmdline_data_ptr : cmd
// global_data, *global_data_ptr : gd

// NAME STRUCTURES:

// VARIABLES OR PARAMETERS - 
//		NameOfVariable, NameOfParameter (dont use lots of capital letters)
// DEFINED PARAMETERS - NAMEOFPARAMETER
// ROUTINES AND FUNCTIONS - Name_Of_Routine(...)
// NAME OF FILES - name_of_file.c (or h)

// Use "_" the less possible in constructing the names

#include "../../../General_libs/general/stdinc.h"
#include "../../../General_libs/math/vectmath.h"
#include "../../../General_libs/general/getparam.h"

#define global

#include "globaldefs.h"
#include "cmdline_defs.h"
#include "protodefs.h"

int main(int argc, string argv[])
{
    gd.cpuinit = cputime();
    InitParam(argv, defv);
    StartRun(argv[0], HEAD1, HEAD2, HEAD3);
	MainLoop();
	EndRun();
    return 0;
}

