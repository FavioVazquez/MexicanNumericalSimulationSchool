't" t
.TH template03 1 "January 2012" UNIX "NagBody PROJECT"
.na
.nh   

.SH NAME
template03 - TEMPLATE for developing NagBody codes
.SH SYNOPSIS
\fBtemplate03\fR [ \fIparameter_file_name\fR ] [ \fIoptions\fR ] 
.sp

.SH DESCRIPTION
\fBtemplate03\fR - Template to simulate the evolution of a N-body system interacting with a given force.

.SH OPTIONS
All the options have the structure
.sp
\fIoption_name\fR=<option_value>
.sp
except option \fB-help\fR.
.sp

Options and their possible values are:

.IP "\fB-help\fR" 12
By writting

.sp
template03 -help
.sp

you will get the list of all parameters and their default values. An option may have an alias which is a short name of the option. If an option has an alias in the list above it comes after its description surrounded by brackets tagged with 'a:'. For example,

.sp
option_name=<option_value>	... Description ... [a: opt]
.sp
here 'opt' is the short name of the option. In the description of the options below, when an option has an alias it will be noted in the same way but before its description.

.IP "\fBparamfile\fR" 12
is the name file with the values of the input parameters. Overwrite parameters
values below. You may input this filename by only writing:
.sp
template03 parameters_input_file_name
.sp
Parameter input file may be created by hand with the editor of your choice. Comment lines start with an "%". Follow each name option with a blank space and the option value. The order of the option lines does not matter.  Also you may create an example input file by executing
.sp
template03
.sp
This will run the \fBtemplate03\fR code with default values generating a test data internally, and when it finish you will have in your running directory the file "parameters_null-template03-usedvalues". Now you may edit this file to adapt to your own plotting parameters. It may be helpful to change this file name to whatever apropriate.

.IP "\fBeps\fR" 12
is the force smoothing parameter.

.IP "\fBnbody\fR" 12
is the number of bodies to simulate.
.sp
Note: it is recommended that this number is given as power of 2.

.IP "\fBdtime\fR" 12
[a: dt] is the integration time step. Can be given as a ration of two numbers.

.IP "\fBtstop\fR" 12
is the time to stop the simulation.

.IP "\fBseed\fR" 12
is the Random number seed for the test run.

.IP "\fBicfile\fR" 12
[a: ic] you give here the name of the file with the N-body initial data.

.IP "\fBicfilefmt\fR" 12
[a: icfmt] is the format of the 'icfile'. 'snap-bin' (Binary) or 'snap-ascii' (ASCII).

.IP "\fBsnapout\fR" 12
[a: out] you give here the name structure for the output of N-body snaps. The format follows as the ones used in C-language for integers ("namefile%0#d"), where "#" is an integer.

.IP "\fBsnapoutfmt\fR" 12
[a: ofmt] you tell the code the format of the snaps output. There are three options 'snap-ascii', 'snap-bin', or 'snap-pv'. Single quotation marks are not written.

.IP "\fBdtout\fR" 12
this is the output time step. The out files will be written every dtout time step.

.IP "\fBdtoutinfo\fR" 12
this is the output info time step. 
The standard output will be written every dtoutinfo time step.

.IP "\fBstatefile\fR" 12
[a: state] you give here the name of a file where the run state will be saved. If it is null no run state will be saved.

.IP "\fBstepState\fR" 12
you give here how to save the state of the run. The run will be saved every stepState.

.IP "\fBrestorefile\fR" 12
[a: restore] if it is not null a run will be restarted from the data stored in this file.

.IP "\fBoptions\fR" 12
[a: opt] you may give here various code behavior options. They are, "reset-time" (inputdata); "out-phi" (outputdata); "out-acc" (outputdata). If you save a state file, this parameter is saved.

.SH EXAMPLES
template03 nbody=512 dtime=1/512 snapout=snap%03d

.SH SEE ALSO
template01(1), md_lj_tree(1)

.SH COPYRIGHT
Copyright (C) 1999-2012
.br
M.A. Rodriguez-Meza
.br
