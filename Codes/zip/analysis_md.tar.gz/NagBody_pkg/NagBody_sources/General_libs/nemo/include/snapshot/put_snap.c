
#ifdef NEWIO
#include "put_snap-ran.c"
#else
#include "put_snap-old.c"
#endif
