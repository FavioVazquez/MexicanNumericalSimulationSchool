't" t
.TH templateBessel 1 "January 2010" UNIX "NagBody PROJECT"
.na
.nh   

.SH NAME
templateBessel - TEMPLATE for developing NagBody codes

.SH SYNOPSIS
\fBtemplateBessel\fR [ \fIoptions\fR ]
.sp

.SH DESCRIPTION
\fBtemplateBessel\fR - code to compute Bessel functions:
BesselI(0,x), BesselI(1,x), BesselK(0,x), BesselK(1,x),.

.SH OPTIONS
The options have the structure
.sp
\fIoption_name\fR = <option_value>

.sp
except option \fB-help\fR.
.sp
Options and their possible values are:

.IP "\fB-help\fR" 12
By writting

.sp
templateBessel -help
.sp

you will get the list of all parameters and their default values.
An option may have an alias which is a short name of the option. If an option
has an alias in the list above it comes after its description
surrounded by brackets tagged with 'a:'. For example,

.sp
option_name=<option_value>	... Description ... [a: opt]

.sp
here 'opt' is the short name of the option. In the description of the options
below, when an option has an alias it will be noted in the same way but before
its description.

.IP "\fBxvalue\fR" 12
[a: x]
It is the value of x where the Bessel functions are evaluated. 


.SH EXAMPLES
templateBessel x=3.2

.SH REFERENCE
Abramowitz & Stegun, chapter 9.

.SH SEE ALSO
nplot2d(1)

.SH COPYRIGHT
Copyright (C) 1999-2010
.br
M.A. Rodriguez-Meza
.br
