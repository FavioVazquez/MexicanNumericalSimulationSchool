't" t
.TH nplot2d 1 "January 2011" UNIX "NagBody PROJECT"
.na
.nh   

.SH NAME
\fBnplot2d\fR - Code for 2D plotting of data files.

.SH SYNOPSIS
\fBnplot2d\fR [ \fIparameter_file_name\fR ] [ \fIoptions\fR ] 
.sp

.SH DESCRIPTION
\fBnplot2d\fR - Plot data in files. The data format is in column form.

.SH OPTIONS
All the options have the structure
.sp
\fIoption_name\fR=<option_value>

.sp
except option \fB-help\fR.
.sp
Options and their possible values are:

.IP "\fB-help\fR" 12
By writting

.sp
nplot2d -help
.sp

you will get the list of all parameters and their default values.
An option may have an alias which is a short name of the option. If an option
has an alias in the list above it comes after its description
surrounded by brackets tagged with 'a:'. For example,

.sp
option_name=<option_value>	... Description ... [a: opt]
.sp
here 'opt' is the short name of the option. In the description of the options
below, when an option has an alias it will be noted in the same way but before
its description.

.IP "\fBparamfile\fR" 12
is the name file with the values of the input parameters.
You may input this filename by only writing:
.sp
nplot2d parameters_input_file_name
.sp
Parameter input file may be created by hand with the editor of your choice. Comment lines start
with an "%". Follow each name option with a blank space and the option value.
The order of the option lines does not matter.  
Also you may create an example input file
by executing
.sp
nplot2d
.sp
This will run the \fBnplot2d\fR code with default values generating
a test data set internally,
and when it finish you will have in your
running directory the file "parameters_null-nplot2d-usedvalues".
Now you may edit this file to adapt
to your own plotting parameters.
It may be helpful to change this file name to whatever apropriate.
Also, the data set is saved to a file named "testdata.dat".

Note: The combined use of a parameter file followed by other command line
options can be very useful. For example, you may have several similar
plots that can share the same parameter file and just modified one
parameter or a few parameters that distinguishes each individual plot.

.IP "\fBgraphicsarray\fR" 12
[a: ga] With this option we get the graphics array style. The format is <nrows x ncols>,
i.e. number of rows by number of columns (do not type in the blank spaces).
The plotting area is divided in
nrows times ncols plotting sub-areas.

.IP "\fBinputfile\fR" 12
[a: in] you give here the name of the file which contains the data you want to
visualize.

.IP "\fBoutputfile\fR" 12
[a: o] you give here the name of the file to save the plot of the data you have
visualized. Use this option in combination with \fBdev\fR option.

.IP "\fBdev\fR" 12
you give here the device where the plot will be displayed. Can be 
<xwin> (Xwindows), <aqt> (Aqua in Mac OSX), <psc> (color postscript),
<ps> (B&W postscript). Default value is <xwin>.

.IP "\fBori\fR" 12
This option is to display your plot as landscape <0>, portrait <1>,
seascape <2>, upside-down <3>.

.IP "\fBaspectratio\fR" 12
[a: a] The aspect ratio of the display is controled with this option.
Default: same as output device.

.IP "\fBgeometry\fR" 12
[a: geo] The geometry of the display window is given with this option.
You type this option as \fBgeometry\fR=<wpixels x hpixesl>, i.e., number
of pixels width by the number of pixels in height.
By default the code use <640x480>.

.IP "\fBlocatemode\fR" 12
With this option you may locate pixels info such as world or display 
coordinates. World coordinates are relative to the data, and
display coordinates are relative to the display device and are in 
the range (0, 1).

.IP "\fBepilog\fR" 12
you may give here various code additional behavior options. 
At the moment there are none.

.IP "\fBplotjoined\fR" 12
[a: pj] You tell the code to plot a line joining the points.
Possible values <true> or <false>. Default value is <true>.
The value may be type in as the following equivalent symbols.
For true: <true>, <1>, <t>, <T>, <y>, <Y>.
For false: <false>, <0>, <f>, <F>, <n>, <N>.
If you are plotting several data sets you should type
the option as \fBplotjoined\fR=<1,0,1,...> or equivalent characters.

.IP "\fBplottype\fR" 12
Plot type: normal <0>, normal-log <1>, log-normal <2>, log-log <3>.
Be careful with your data in the case of log style. Log function are not
defined for negative values and diverge when the argument goes to zero.

.IP "\fBusingcolumns\fR" 12
[a: uc] you give here the columns to plot. If you are plotting several curves
of data sets, files are given in the option \fBinputfile\fR separated by comma,
then the option \fBusingcolumns\fR must have the same number of pairs of
columns.

.IP "\fBwithdots\fR" 12
[a: wd] You tell the code to plot with dots (pixels).
Possible values <true> or <false> or their equivalent values 
(see \fBplotjoined\fR instructions above).

.IP "\fBwithsymbols\fR" 12
[a: ws] You tell the code to plot with symbols. Possible values <true> or 
<false> or their equivalent values (see \fBplotjoined\fR instructions above).


.IP "\fBxrange\fR" 12
[a: xr] \fBnplot2d\fR by default autoscale to fit in the windows all the points. But,
you may use \fBxrange\fR to adjust the display range in the x-axis. Use as
\fBxrange\fR=<xmin:xmax>. Its default value is <autoscale>.

.IP "\fByrange\fR" 12
[a: yr] Same explanation as \fBxrange\fR.

.IP "\fBxlabel\fR" 12
[a: xl] you give here the label string for x-axis.

.IP "\fBylabel\fR" 12
[a: yl] you give here the label string for y-axis.

.IP "\fBplotlabel\fR" 12
you give here the label string for the plot.

.IP "\fBlabelcolor\fR" 12
With this option you control the color of the plot labels, such axes and plot
labels.

.IP "\fBlabelfontsize\fR" 12
This option control the font size of the labels.

.IP "\fBlabelfontweight\fR" 12
This option control the font weight of the labels.

.IP "\fBlegends\fR" 12
If you plot several sets of data they can be labelled in the plot
using this option.

.IP "\fBlegendspos\fR" 12
This option control the position of the lengends. Can be upper-left <0>,
upper-right <1>, bottom-left <2>, bottom-right <3>.

.IP "\fBlegendsfontsize\fR" 12
This option control the font size of the lengends.

.IP "\fBlegendsfontweight\fR" 12
This option control the font weight of the lengends.

.IP "\fBfontset\fR" 12
With this option you may switch between font sets.

.IP "\fBfontchr\fR" 12
With this option you set the character font. Normal <1>, Roman <2>,
Italic <3>, Scrip <4>.

.IP "\fBxaxis\fR" 12
With option x-axis is drawn. Its values are <true> or <false>. Default
is <false>.

.IP "\fByaxis\fR" 12
With option y-axis is drawn. Its values are <true> or <false>. Default
is <false>.

.IP "\fBaxesorigin\fR" 12
You set with this option the position of the axes origin. By default
its value is <0,0>, values in the world coordinates.

.IP "\fBframe\fR" 12
A frame surrounding the plot is drawn. Its values are <true> or <false>. 
Default is <true>.

.IP "\fBframestyle\fR" 12
Sets the framestyle.

.IP "\fBnlxdigmax\fR" 12
Sets the maximum field width for numeric labels on x-axis.

.IP "\fBnlydigmax\fR" 12
Sets the maximum field width for numeric labels on y-axis.

.IP "\fBnlsize\fR" 12
Sets the font size for numeric labels on axes.

.IP "\fBnlcolor\fR" 12
Sets the font color for numeric labels on axes.

.IP "\fBaxescolor\fR" 12
Sets the color of axes.

.IP "\fBaxeswidth\fR" 12
Sets axes width.

.IP "\fBaxestype\fR" 12
Sets axes line type that will be used to draw the axes.

.IP "\fBgridlines\fR" 12
Tells if grid lines will be drawn.

.IP "\fBlinetype\fR" 12
Sets line type that will be used to draw the curve if \fBplotjoined\fR=<true>.
It is an integer. 
If several data sets are drawing the option may be
typed in as <i,j,k,l,...> (a series of integers). For
simplicity and if appropriate you may want to set
the line type for the first data set and the other
data set line type will be fixed to the first one value.

.IP "\fBlinewidth\fR" 12
Lines width are controled with this option.

.IP "\fBlinecolor\fR" 12
Lines color are controled with this option.

.IP "\fBsymboltype\fR" 12
Sets symbol type that will be used to draw a data set.
It is an integer. 
If several data sets are drawing the option may be
typed in as <i,j,k,l,...> (a series of integers). For
simplicity and if appropriate you may want to set
the symbol type for the first data set and the other
data set symbol type will be fixed to the first one value.

.IP "\fBsymbolsize\fR" 12
Symbol size is controled with this option.

.IP "\fBsymbolweight\fR" 12
Symbol weight is controled with this option.

.IP "\fBsymbolcolor\fR" 12
Symbol color are controled with this option.

.IP "\fBwitherrorbars\fR" 12
[a: web] Error bars will be drawn if indicated with this options.
This option is given in the form: \fBwitherrorbars\fR=<1,0,0,1,0,1,1...>.
Each one or zero is for a given data set in \fBinputfile\fR.
You can use 'f', 'F', 'n', 'N' or 'false' instead of '0'
and for '1' you may use 't', 'T', 'y', 'Y', 'true'.

.IP "\fBerrorbarstype\fR" 12
[a: errt] Error bars will be drawn if indicated with \fBwitherrorbars\fR option.
and \fBerrorbarstype\fR=<0> (default) will indicate to use the third column
in \fBusingcolumns\fR=<n1:n2:n3> as the size of the error bars. If
\fBerrorbarstype\fR=<1> then we have to give \fBusingcolumns\fR=<n1:n2:n3:n4>
and third and fourth columns will be the minimum and maximum values of the
error bars, respectively.

.IP "\fBtext1\fR" 12
Additional text can be drawn with this option. You type in it as
\fBtext1\fR=<string>.

.IP "\fBtext1side\fR" 12
Specify edge and direction (bottom and vertical, ...)
of the text given in the option \fBtext1\fR.

.IP "\fBtext1disp\fR" 12
Specify the position of the text given in the option \fBtext1\fR,
measured outwards from the specified edge.

.IP "\fBtext1pos\fR" 12
Specify position of the text given in the option \fBtext1\fR, 
along the specified edge.

.IP "\fBtext1just\fR" 12
Specify text justification of the text given in the option \fBtext1\fR.

.IP "\fBtext1size\fR" 12
Specify text size of the text given in the option \fBtext1\fR.

.IP "\fBtext1weight\fR" 12
Specify text weight of the text given in the option \fBtext1\fR.

.IP "\fBtext1color\fR" 12
Specify text color of the text given in the option \fBtext1\fR.

.IP "\fBtext2\fR" 12
Additional text can be drawn with this option. You type in it as
\fBtext2\fR=<string>.

.IP "\fBtext2side\fR" 12
Specify edge and direction (bottom and vertical, ...)
of the text given in the option \fBtext2\fR.

.IP "\fBtext2disp\fR" 12
Specify the position of the text given in the option \fBtext2\fR,
measured outwards from the specified edge.

.IP "\fBtext2pos\fR" 12
Specify position of the text given in the option \fBtext2\fR, 
along the specified edge.

.IP "\fBtext2just\fR" 12
Specify text justification of the text given in the option \fBtext2\fR.

.IP "\fBtext2size\fR" 12
Specify text size of the text given in the option \fBtext2\fR.

.IP "\fBtext2weight\fR" 12
Specify text weight of the text given in the option \fBtext2\fR.

.IP "\fBtext2color\fR" 12
Specify text color of the text given in the option \fBtext2\fR.

.IP "\fBtext3\fR" 12
Additional text can be drawn with this option. You type in it as
\fBtext3\fR=<string>.

.IP "\fBtext3side\fR" 12
Specify edge and direction (bottom and vertical, ...)
of the text given in the option \fBtext3\fR.

.IP "\fBtext3disp\fR" 12
Specify the position of the text given in the option \fBtext3\fR,
measured outwards from the specified edge.

.IP "\fBtext3pos\fR" 12
Specify position of the text given in the option \fBtext3\fR, 
along the specified edge.

.IP "\fBtext3just\fR" 12
Specify text justification of the text given in the option \fBtext3\fR.

.IP "\fBtext3size\fR" 12
Specify text size of the text given in the option \fBtext3\fR.

.IP "\fBtext3weight\fR" 12
Specify text weight of the text given in the option \fBtext3\fR.

.IP "\fBtext3color\fR" 12
Specify text color of the text given in the option \fBtext3\fR.

.IP "\fBtext4\fR" 12
Additional text can be drawn with this option. You type in it as
\fBtext4\fR=<string>. This option follow a diferent scheme for
positioning and formating than the options \fBtext1\fR, \fBtext2\fR,
\fBtext3\fR.

.IP "\fBtext4x\fR" 12
Specify x position (world coordinates) of the text given in the 
option \fBtext4\fR. 

.IP "\fBtext4y\fR" 12
Specify y position (world coordinates) of the text given in the 
option \fBtext4\fR. 

.IP "\fBtext4dx\fR" 12
Specify direction along x-axis (world coordinates) of the text given in the 
option \fBtext4\fR. 

.IP "\fBtext4dy\fR" 12
Specify direction along y-axis (world coordinates) of the text given in the 
option \fBtext4\fR. 

.IP "\fBtext4just\fR" 12
Specify text justification of the text given in the option \fBtext4\fR.

.IP "\fBtext4size\fR" 12
Specify text size of the text given in the option \fBtext4\fR.

.IP "\fBtext4weight\fR" 12
Specify text weight of the text given in the option \fBtext4\fR.

.IP "\fBtext4color\fR" 12
Specify text color of the text given in the option \fBtext4\fR.

.IP "\fBshowall\fR" 12
Turns on invisible options. Default <false>.

.IP "\fBh\fR" 12
Print out this message. Default <false>.

.IP "\fBv\fR" 12
Print out the PLplot library version number. Default <false>.

.IP "\fBverbose\fR" 12
Be more verbose than usual. Default <false>.

.IP "\fBdebug\fR" 12
Print debugging info (implies \fBverbose\fR). Default <false>.

.IP "\fBhack\fR" 12
Enable driver-specific hack(s). Default <false>.

.IP "\fBwplt\fR" 12
Relative coordinates [0-1] of window into plot [xl,yl,xr,yr].

.IP "\fBmar\fR" 12
Margin space in relative coordinates (0 to 0.5, default 0).

.IP "\fBjx\fR" 12
Page justification in x (-0.5 to 0.5, default 0).

.IP "\fBjy\fR" 12
Page justification in y (-0.5 to 0.5, default 0).

.IP "\fBori\fR" 12
Plot orientation (0,1,2,3=landscape,portrait,seascape,upside-down).

.IP "\fBfreeaspect\fR" 12
Allow aspect ratio to adjust to orientation swaps. Default <false>.

.IP "\fBportrait\fR" 12
Sets portrait mode (both orientation and aspect ratio). Default <false>.

.IP "\fBwidth\fR" 12
Sets pen width (0 <= width).

.IP "\fBncol0\fR" 12
Number of colors to allocate in cmap 0 (upper bound).

.IP "\fBncol1\fR" 12
Number of colors to allocate in cmap 1 (upper bound).

.IP "\fBfam\fR" 12
Create a family of output files. Default <false>.

.IP "\fBfsiz\fR" 12
Output family file size (e.g., \fBfsiz\fR=<0.5G>, default <MB>).

.IP "\fBfbeg\fR" 12
First family member number on output.

.IP "\fBfinc\fR" 12
Increment between family members.

.IP "\fBflen\fR" 12
Family member number minimum field width.

.IP "\fBnopixmap\fR" 12
Do not use pixmaps in X-based drivers.

.IP "\fBdb\fR" 12
Double buffer X window output. Default <false>.

.IP "\fBnp\fR" 12
No pause between pages. Default <false>.

.IP "\fBbufmax\fR" 12
bytes sent before flushing output.

.IP "\fBdpi\fR" 12
Resolution, in dots per inch (e.g. \fBdpi\fR=<360x360>).

.IP "\fBcompression\fR" 12
Sets compression level in supporting devices.

.IP "\fBdrvopt\fR" 12
Driver specific options.

.IP "\fBdisplay\fR" 12
Sets X server to contact.

.IP "\fBbackground\fR" 12
[a: bg] Sets the background color.

.SH DATA FILE FORMAT
The data files that are accepted as input files to \fBnplot2d\fR must
be in column form format. A "#" may be used to comment the file and
it is a dummy line for the code.

.SH EXAMPLES
The command:
.sp
nplot2d

.sp
will generate a file 'testdata.dat' a plot column 1 vs column 2 by default.

.sp
Now, them comand:

.sp
nplot2d inputfile=testdata.dat usingcolumns=1:2 dev=xwin geometry=640x480

.sp
Display in an X-Window a line conecting the points described by 
columns 1 and 2 in file 'testdata.dat'.
The geometry of the window is 640 pixels width by 480 pixesl height. The same 
result
is obtained if you type in the command:

.sp
nplot2d in=testdata.dat uc=1:2 geo=640x480

To plot error bars type in, for example,
.sp
nplot2d inputfile=testdata.dat usingcolumns=1:2:3:4 web=1 errorbarstype=1
plotjoined=false ws=true symboltype=4 symbolsize=0.5

.sp
Note that the default value of \fBdev\fR is <xwin>. If you want to save the
plot in a encapsulated postscript file named 'testdata.eps' do

.sp
nplot2d in=testdata.dat dev=psc o=testdata.eps ori=1
.sp
We have added the option \fBori\fR to have portrait orientation. A black and 
white postscript version is obtained with
.sp
nplot2d in=testdata.dat dev=ps o=testdata.eps ori=1

.sp
Other interesting option is \fBgraphicsarray\fR, try for example,

.sp
nplot2d in=testdata.dat,testdata.dat,testdata.dat,testdata.dat
ws=0,0,0,1 uc=1:2,1:3,1:4,1:4 graphicsarray=4x1 xl=x yl=y geo=300x800

.sp
Note that you should set \fBgeo\fR to display the array of plots apropriately.
.SH SEE ALSO
analysis_md(1), analysis_grav(1), analysis_galaxy(1), nplot3d(1)

.SH COPYRIGHT
Copyright (C) 1999-2011
.br
M.A. Rodriguez-Meza
.br
