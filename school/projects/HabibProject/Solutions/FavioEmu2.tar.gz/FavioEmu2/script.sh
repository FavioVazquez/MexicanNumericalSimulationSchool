#!/bin/bash

for i in {1..4}
do
	./emu.exe
	echo -e "\n"
done
