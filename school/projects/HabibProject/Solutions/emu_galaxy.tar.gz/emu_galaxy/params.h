extern float min_design[5]; 
extern float max_design[5]; 
extern int nk; 
extern int numPC;
extern int nmodels;
extern int nparams; 
extern double logk[661]; 
